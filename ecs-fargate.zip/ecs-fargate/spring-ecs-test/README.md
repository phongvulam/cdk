+ Push image to docker local by command.
  > docker build t <ImageName> .
+ Start image on docker.
  > docker run <ImageName>
+ Open tomcat and test.
    - POST : insert record.
      ![alt text](https://github.com/ledailoi00/cdk/blob/master/ecs-fargate/spring-ecs-test/insert.PNG?raw=true)
    - PUT: update record.
      ![alt text](https://github.com/ledailoi00/cdk/blob/master/ecs-fargate/spring-ecs-test/update.PNG?raw=true)
    - DELETE: delete record.
      ![alt text](https://github.com/ledailoi00/cdk/blob/master/ecs-fargate/spring-ecs-test/delete.PNG?raw=true)
    - GET: select record.
      ![alt text](https://github.com/ledailoi00/cdk/blob/master/ecs-fargate/spring-ecs-test/select.PNG?raw=true)
  
